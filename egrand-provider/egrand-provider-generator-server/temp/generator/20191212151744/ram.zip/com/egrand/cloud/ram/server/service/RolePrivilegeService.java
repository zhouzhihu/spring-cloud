package com.egrand.cloud.ram.server.service;

import com.egrand.cloud.ram.client.model.entity.RolePrivilege;
import com.egrand.core.mybatis.base.service.IBaseService;

/**
 *  服务类
 *
 * @author ZZH
 * @date 2019-12-12
 */
public interface RolePrivilegeService extends IBaseService<RolePrivilege> {

}
