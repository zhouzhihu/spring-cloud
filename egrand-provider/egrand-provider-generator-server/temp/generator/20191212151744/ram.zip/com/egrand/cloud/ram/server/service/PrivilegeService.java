package com.egrand.cloud.ram.server.service;

import com.egrand.cloud.ram.client.model.entity.Privilege;
import com.egrand.core.mybatis.base.service.IBaseService;

/**
 *  服务类
 *
 * @author ZZH
 * @date 2019-12-12
 */
public interface PrivilegeService extends IBaseService<Privilege> {

}
