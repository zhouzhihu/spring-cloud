package com.egrand.cloud.yuncang.file.server.service;

import com.egrand.cloud.yuncang.file.client.model.entity.UserFolder;
import com.egrand.core.mybatis.base.service.IBaseService;

/**
 *  服务类
 *
 * @author ZZH
 * @date 2019-12-17
 */
public interface UserFolderService extends IBaseService<UserFolder> {

}
